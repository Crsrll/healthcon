// app/api/bookings/route.js
import { NextResponse } from 'next/server';
import { db } from '@/lib/firebase';
import { collection, query, where, getDocs, addDoc, doc, getDoc } from 'firebase/firestore';
import { timeToMinutes } from '@/lib/timeUtils';
import { createNotification } from '@/lib/createNotification';

// ── GET: FETCH BOOKED SLOTS ──────────────────────────────────────
export async function GET(req) {
  const { searchParams } = new URL(req.url);
  const clinicID = searchParams.get('clinicID');
  const doctorID = searchParams.get('doctorID');
  const date     = searchParams.get('date');

  if (!clinicID || !doctorID || !date) {
    return NextResponse.json({ bookedTimes: [] });
  }

  try {
    const q = query(
      collection(db, 'bookings'),
      where('clinicID', '==', clinicID),
      where('doctorID', '==', doctorID),
      where('date',     '==', date),
      where('status',   'in', ['pending', 'confirmed'])
    );

    const snap = await getDocs(q);
    const bookedTimes = snap.docs.map(doc => doc.data().time);
    return NextResponse.json({ bookedTimes });
  } catch (err) {
    console.error('GET /api/bookings error:', err);
    return NextResponse.json({ bookedTimes: [] }, { status: 500 });
  }
}

// ── POST: CREATE NEW BOOKING ─────────────────────────────────────
export async function POST(req) {
  try {
    const body = await req.json();
    const { clinicID, doctorID, patientID, service, day, time, date } = body;

    if (!clinicID || !doctorID || !patientID || !service || !day || !time || !date) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 });
    }

    // 1. Fetch patient name
    const userSnap = await getDoc(doc(db, 'users', patientID));
    if (!userSnap.exists()) {
      return NextResponse.json({ error: 'Patient profile not found.' }, { status: 404 });
    }
    const userData = userSnap.data();
    const mi = userData.middleInitial ? `${userData.middleInitial} ` : "";
    const fullName = `${userData.firstName} ${mi}${userData.lastName}`.replace(/\s+/g, ' ').trim();

    // 2. Fetch doctor + validate availability
    const doctorSnap = await getDoc(doc(db, 'doctors', doctorID));
    if (!doctorSnap.exists()) {
      return NextResponse.json({ error: 'Doctor not found' }, { status: 404 });
    }
    const doctor = doctorSnap.data();
    const availability = doctor.availability;
    const actualDoctorName = doctor.name;

    const dayMap = {
      Mon: 'Monday', Tue: 'Tuesday', Wed: 'Wednesday',
      Thu: 'Thursday', Fri: 'Friday', Sat: 'Saturday', Sun: 'Sunday',
    };
    const normalizedDay = dayMap[day] ?? day;

    if (!availability.days.includes(normalizedDay)) {
      return NextResponse.json({ error: 'Doctor unavailable on selected day' }, { status: 400 });
    }

    const selectedMinutes = timeToMinutes(time);
    const startMinutes    = timeToMinutes(availability.startTime);
    const endMinutes      = timeToMinutes(availability.endTime);

    if (selectedMinutes < startMinutes || selectedMinutes >= endMinutes) {
      return NextResponse.json({ error: 'Selected time outside doctor schedule' }, { status: 400 });
    }

    // 3. Fetch clinic name for notification
    let clinicName = "the clinic";
    try {
      const clinicSnap = await getDoc(doc(db, 'clinics', clinicID));
      if (clinicSnap.exists()) clinicName = clinicSnap.data().clinicName ?? clinicName;
    } catch (_) {}

    // 4. Save booking
    const ref = await addDoc(collection(db, 'bookings'), {
      clinicID,
      doctorID,
      doctorName: `Dr. ${actualDoctorName}`,
      patientID,
      patientName: fullName,
      service,
      day,
      time,
      date,
      status: 'pending',
      createdAt: new Date().toISOString(),
    });

    // 5. ── Notify the CLINIC of the new booking request ──
    await createNotification({
      recipientID: clinicID,
      type:   'booking_requested',
      title:  'New Appointment Request',
      body:   `${fullName} requested an appointment on ${date} at ${time} for ${service}.`,
      linkTo: '/clinic/pending-requests',
      meta:   { bookingID: ref.id, patientID, patientName: fullName, date, time, service },
    });

    return NextResponse.json({ success: true, id: ref.id });
  } catch (err) {
    console.error('POST /api/bookings error:', err);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}